// --- Element Selectors (bovenaan je script.js) ---
const templateSelectionDiv = document.getElementById('template-selection');
const questionAreaDiv = document.getElementById('question-area');
const finalPromptAreaDiv = document.getElementById('final-prompt-area');
// ... selecteer alle andere relevante elementen (knoppen, input, etc.)
const questionTitleEl = document.getElementById('question-title');
const questionTipEl = document.getElementById('question-tip');
const answerInputEl = document.getElementById('answer-input');
const progressIndicatorEl = document.getElementById('progress-indicator');
const generatedPromptEl = document.getElementById('generated-prompt');
const nextButton = document.getElementById('next-button');
const backButton = document.getElementById('back-button');
const restartButton = document.getElementById('restart-button');
const restartButtonFinal = document.getElementById('restart-button-final');
const copyButton = document.getElementById('copy-button');
const saveButton = document.getElementById('save-button');
const savedPromptsListEl = document.getElementById('saved-prompts-list');


// --- Event Listeners ---
templateSelectionDiv.addEventListener('click', handleTemplateSelection);
nextButton.addEventListener('click', handleNext);
backButton.addEventListener('click', handleBack);
restartButton.addEventListener('click', handleRestart);
restartButtonFinal.addEventListener('click', handleRestart);
copyButton.addEventListener('click', copyToClipboard);
saveButton.addEventListener('click', saveCurrentPrompt);
// Event listener voor laden van opgeslagen prompts bij start
document.addEventListener('DOMContentLoaded', loadSavedPrompts);

// --- Core Functions ---

function handleTemplateSelection(event) {
    if (event.target.tagName === 'BUTTON' && event.target.dataset.template) {
        currentState.selectedTemplate = event.target.dataset.template;
        currentState.currentStepIndex = 0;
        currentState.answers = {}; // Reset antwoorden
        templateSelectionDiv.classList.remove('active');
        questionAreaDiv.classList.add('active');
        finalPromptAreaDiv.classList.remove('active');
        renderStep();
    }
}

function renderStep() {
    const template = templates[currentState.selectedTemplate];
    if (!template || currentState.currentStepIndex < 0) return; // Veiligheidscheck

    if (currentState.currentStepIndex >= template.length) {
        // Alle vragen beantwoord, toon finale prompt
        renderFinalScreen();
        return;
    }

    const stepData = template[currentState.currentStepIndex];
    questionTitleEl.textContent = stepData.question;
    questionTipEl.innerHTML = `<i>Tip: ${stepData.tip}</i>`; // innerHTML voor italics
    answerInputEl.value = currentState.answers[stepData.id] || ''; // Laad eerder antwoord indien aanwezig
    answerInputEl.placeholder = `Jouw antwoord voor: ${stepData.question}`;
    // Pas input type aan indien nodig (niet getoond voor eenvoud)

    // Update progress
    progressIndicatorEl.textContent = `Stap ${currentState.currentStepIndex + 1} van ${template.length}`;

    // Zichtbaarheid knoppen
    backButton.style.display = currentState.currentStepIndex > 0 ? 'inline-block' : 'none';
}

function saveCurrentAnswer() {
    const template = templates[currentState.selectedTemplate];
     if (!template || currentState.currentStepIndex < 0 || currentState.currentStepIndex >= template.length) return; // Alleen opslaan als we in een geldige vraagstap zijn

    const stepData = template[currentState.currentStepIndex];
    currentState.answers[stepData.id] = answerInputEl.value.trim();
}

function handleNext() {
    saveCurrentAnswer();
    const template = templates[currentState.selectedTemplate];
    if (currentState.currentStepIndex < template.length) { // Check of we niet al bij de laatste stap waren
         currentState.currentStepIndex++;
    }
    renderStep(); // rendert ofwel volgende stap, ofwel finale scherm
}


function handleBack() {
    if (currentState.currentStepIndex > 0) {
        // Optioneel: saveCurrentAnswer() hier ook aanroepen? Ligt aan gewenste UX.
        currentState.currentStepIndex--;
        renderStep();
    }
}

function handleRestart() {
    currentState = {
        selectedTemplate: null,
        currentStepIndex: -1,
        answers: {}
    };
    // Verberg vraag/finale divs, toon template selectie
    questionAreaDiv.classList.remove('active');
    finalPromptAreaDiv.classList.remove('active');
    templateSelectionDiv.classList.add('active');
    // Wis eventuele inhoud
    answerInputEl.value = '';
    generatedPromptEl.textContent = '';
}

function generatePrompt() {
    const answers = currentState.answers;
    const templateType = currentState.selectedTemplate || 'onbekend type';
    let prompt = `Genereer een ${templateType}.\n\n`; // Begin met type

    // Loop door de vragen van het GESELECTEERDE template om de volgorde te respecteren
    const templateQuestions = templates[currentState.selectedTemplate];
    if (templateQuestions) {
        templateQuestions.forEach(step => {
            if (answers[step.id]) { // Voeg alleen toe als er een antwoord is
                prompt += `**${step.question.replace('?', '')}:** ${answers[step.id]}\n`; // Maak vraag bold, verwijder vraagteken
            }
        });
    } else {
        // Fallback als template onbekend is (zou niet moeten gebeuren)
         for (const key in answers) {
             if (answers[key]) {
                 prompt += `**${key}:** ${answers[key]}\n`;
             }
         }
    }


    prompt += "\nGebruik bovenstaande informatie om de tekst te genereren.";
    return prompt;
}

function renderFinalScreen() {
    questionAreaDiv.classList.remove('active');
    finalPromptAreaDiv.classList.add('active');
    generatedPromptEl.textContent = generatePrompt();
}

function copyToClipboard() {
    const promptText = generatedPromptEl.textContent;
    navigator.clipboard.writeText(promptText)
        .then(() => {
            alert('Prompt succesvol gekopieerd naar klembord!');
        })
        .catch(err => {
            console.error('Fout bij kopiëren: ', err);
            alert('Kopiëren mislukt. Probeer het handmatig.');
        });
}

// --- Local Storage Functies ---
function saveCurrentPrompt() {
    const promptText = generatedPromptEl.textContent;
    if (!promptText) {
        alert('Er is nog geen prompt gegenereerd om op te slaan.');
        return;
    }
    // Genereer een unieke key, bv. op basis van tijdstempel
    const key = `prompt_${Date.now()}`;
    // Sla de prompt tekst en misschien de antwoorden op
    const dataToSave = {
        prompt: promptText,
        answers: currentState.answers, // Handig voor later bewerken
        template: currentState.selectedTemplate,
        timestamp: new Date().toLocaleString('nl-NL')
    };

    try {
        localStorage.setItem(key, JSON.stringify(dataToSave));
        alert('Prompt opgeslagen!');
        loadSavedPrompts(); // Update de lijst direct
    } catch (e) {
        console.error("Opslaan mislukt (mogelijk localStorage vol?):", e);
        alert("Opslaan van prompt mislukt.");
    }
}

function loadSavedPrompts() {
    savedPromptsListEl.innerHTML = ''; // Leeg de lijst
    const keys = Object.keys(localStorage);
    keys.forEach(key => {
        if (key.startsWith('prompt_')) {
            try {
                 const savedData = JSON.parse(localStorage.getItem(key));
                 const listItem = document.createElement('li');

                 // Maak inhoud voor het lijstitem (bv. titel/datum + knoppen)
                 const titleSpan = document.createElement('span');
                 titleSpan.textContent = `Prompt (${savedData.template || 'Onbekend'}) - ${savedData.timestamp || 'Geen datum'}`;
                 titleSpan.style.cursor = 'pointer';
                 titleSpan.title = 'Klik om prompt te bekijken/laden';
                 titleSpan.onclick = () => {
                    // Toon de opgeslagen prompt in het finale scherm
                    currentState.answers = savedData.answers || {}; // Laad antwoorden
                    currentState.selectedTemplate = savedData.template; // Laad template
                    // Optioneel: ga direct naar finale scherm of laat gebruiker kiezen
                    renderFinalScreen(); // Toont direct de prompt
                    // Scroll naar het prompt gebied
                    finalPromptAreaDiv.scrollIntoView({ behavior: 'smooth' });

                 };


                 const deleteButton = document.createElement('button');
                 deleteButton.textContent = 'Verwijder';
                 deleteButton.onclick = (e) => {
                      e.stopPropagation(); // Voorkom dat klik op titel ook afgaat
                      if (confirm('Weet je zeker dat je deze opgeslagen prompt wilt verwijderen?')) {
                          localStorage.removeItem(key);
                          loadSavedPrompts(); // Herlaad de lijst
                      }
                 };

                 listItem.appendChild(titleSpan);
                 listItem.appendChild(deleteButton);
                 savedPromptsListEl.appendChild(listItem);

            } catch(e) {
                console.error(`Kon opgeslagen prompt niet laden (key: ${key}):`, e);
                // Optioneel: verwijder ongeldige entry?
                // localStorage.removeItem(key);
            }
        }
    });
     // Toon/verberg de 'Opgeslagen Prompts' sectie
     document.getElementById('saved-prompts-area').style.display = savedPromptsListEl.children.length > 0 ? 'block' : 'none';
}


// --- Initialisatie ---
function initializeApp() {
    // Verberg alle stappen behalve template selectie bij start
    questionAreaDiv.classList.remove('active');
    finalPromptAreaDiv.classList.remove('active');
    templateSelectionDiv.classList.add('active');
    loadSavedPrompts(); // Laad opgeslagen prompts bij het starten van de app
}

initializeApp(); // Start de app logica