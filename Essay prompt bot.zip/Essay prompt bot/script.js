// --- Data Structuur voor Templates ---
const templates = {
    essay: [
        { id: 'topic', question: 'Wat is het hoofdonderwerp of de centrale vraag van je essay?', tip: 'Formuleer dit zo specifiek mogelijk. Bijvoorbeeld: "De impact van X op Y in periode Z".', type: 'textarea' },
        { id: 'thesis', question: 'Wat is de belangrijkste stelling (thesis statement) of boodschap die je wilt overbrengen?', tip: 'Dit is de rode draad van je essay. Wat wil je bewijzen of aantonen?', type: 'textarea' },
        { id: 'audience', question: 'Voor wie schrijf je dit essay?', tip: 'Denk aan je docent, medestudenten, een breder publiek? Dit beïnvloedt toon en diepgang.', type: 'text' },
        { id: 'purpose', question: 'Wat is het hoofddoel van je essay?', tip: 'Wil je informeren, analyseren, overtuigen, reflecteren, of iets anders?', type: 'text' },
        { id: 'keyPoints', question: 'Welke specifieke punten, argumenten of secties moeten zeker aan bod komen?', tip: 'Lijst de kernonderdelen of hoofdargumenten op die je wilt behandelen.', type: 'textarea' },
        { id: 'structure', question: 'Is er een specifieke structuur vereist?', tip: 'Bijvoorbeeld: Inleiding, 3 hoofdpunten met elk 2 alinea\'s, Conclusie. Of thematische indeling?', type: 'text' },
        { id: 'length', question: 'Wat is de geschatte of vereiste lengte?', tip: 'Geef het aantal woorden of pagina\'s. Dit helpt de AI de diepgang te bepalen.', type: 'text' }, // Gebruik text voor flexibiliteit (bv "ongeveer 1500 woorden")
        { id: 'tone', question: 'Welke toon moet het essay hebben?', tip: 'Formeel, academisch, objectief, kritisch, persoonlijk, overtuigend?', type: 'text' },
        { id: 'sources', question: 'Moeten er specifieke bronnen gebruikt worden, of een bepaald type bron?', tip: 'Bijv. academische artikelen, specifieke boeken, nieuwsberichten? Of mag de AI algemene kennis gebruiken?', type: 'textarea' },
        { id: 'avoid', question: 'Zijn er dingen die de AI moet vermijden?', tip: 'Denk aan clichés, specifieke argumenten, te informele taal, jargon dat niet uitgelegd wordt.', type: 'textarea' },
    ],
    researchPaper: [
        { id: 'topic', question: 'Wat is het precieze onderwerp van het onderzoeksverslag?', tip: 'Baken het onderwerp goed af.', type: 'textarea' },
        { id: 'researchQuestion', question: 'Wat is de centrale onderzoeksvraag of hypothese?', tip: 'Formuleer een duidelijke, onderzoekbare vraag of stelling.', type: 'textarea' },
        { id: 'background', question: 'Welke achtergrondinformatie of context is essentieel?', tip: 'Geef kort de relevantie en bestaande kennis weer.', type: 'textarea' },
        { id: 'methodology', question: 'Welke onderzoeksmethodologie wordt gebruikt (of moet de AI beschrijven)?', tip: 'Kwalitatief, kwantitatief, literatuurstudie, case study, etc.', type: 'text' },
        { id: 'sections', question: 'Welke standaardsecties moet het verslag bevatten?', tip: 'Typisch: Inleiding, Theoretisch Kader/Literatuurstudie, Methode, Resultaten, Discussie, Conclusie.', type: 'textarea' },
        { id: 'audience', question: 'Voor wie is dit verslag bedoeld?', tip: 'Docent, medestudenten, vakgenoten?', type: 'text' },
        { id: 'length', question: 'Wat is de vereiste lengte/omvang?', tip: 'Aantal woorden of pagina\'s.', type: 'text' },
        { id: 'sources', question: 'Welk type bronnen moet gebruikt worden?', tip: 'Peer-reviewed artikelen, boeken, specifieke datasets?', type: 'textarea' },
        { id: 'tone', question: 'Welke toon is vereist?', tip: 'Objectief, formeel, academisch, precies.', type: 'text' },
    ],
    argument: [
        { id: 'topic', question: 'Over welk onderwerp gaat het betoog?', tip: 'Kies een onderwerp waarover een duidelijk standpunt ingenomen kan worden.', type: 'textarea' },
        { id: 'standpoint', question: 'Wat is jouw duidelijke standpunt (stelling) in dit betoog?', tip: 'Formuleer de hoofdclaim die je gaat verdedigen.', type: 'textarea' },
        { id: 'audience', question: 'Wie probeer je te overtuigen?', tip: 'Denk aan hun voorkennis en mogelijke tegenargumenten.', type: 'text' },
        { id: 'mainArguments', question: 'Wat zijn je belangrijkste argumenten om je standpunt te ondersteunen?', tip: 'Lijst 3-5 sterke argumenten op.', type: 'textarea' },
        { id: 'evidence', question: 'Welk soort bewijs of onderbouwing moet gebruikt worden?', tip: 'Feiten, statistieken, voorbeelden, expert opinions, logische redeneringen?', type: 'textarea' },
        { id: 'counterArguments', question: 'Welke belangrijke tegenargumenten moeten worden genoemd en weerlegd?', tip: 'Laat zien dat je de andere kant begrijpt en kunt ontkrachten.', type: 'textarea' },
        { id: 'tone', question: 'Welke toon moet het betoog hebben?', tip: 'Overtuigend, zelfverzekerd, redelijk, respectvol (ook naar tegenstanders).', type: 'text' },
        { id: 'length', question: 'Wat is de gewenste lengte?', tip: 'Aantal woorden of alinea\'s.', type: 'text' },
        { id: 'conclusion', question: 'Wat moet de conclusie benadrukken?', tip: 'Herhaling standpunt, samenvatting argumenten, oproep tot actie?', type: 'text' },
    ]
};

// --- Globale Staat ---
let currentState = {
    selectedTemplate: null,
    currentStepIndex: -1,
    answers: {}
};

// --- DOM Element Selectors ---
const appDiv = document.getElementById('app');
const templateSelectionDiv = document.getElementById('template-selection');
const questionAreaDiv = document.getElementById('question-area');
const finalPromptAreaDiv = document.getElementById('final-prompt-area');
const savedPromptsSection = document.getElementById('saved-prompts-section');

const progressIndicatorEl = document.getElementById('progress-indicator');
const questionTitleEl = document.getElementById('question-title');
const questionTipEl = document.getElementById('question-tip');
const answerInputEl = document.getElementById('answer-input');

const nextButton = document.getElementById('next-button');
const backButton = document.getElementById('back-button');
const restartButton = document.getElementById('restart-button');
const restartButtonFinal = document.getElementById('restart-button-final');
const editAnswersButton = document.getElementById('edit-answers-button');


const generatedPromptEl = document.getElementById('generated-prompt');
const copyButton = document.getElementById('copy-button');
const saveButton = document.getElementById('save-button');

const viewSavedButton = document.getElementById('view-saved-button');
const backToStartButton = document.getElementById('back-to-start-button');
const savedPromptsListEl = document.getElementById('saved-prompts-list');

// --- Hulpfuncties ---
function showStep(stepId) {
    // Verberg alle hoofdsecties
    templateSelectionDiv.classList.remove('active');
    questionAreaDiv.classList.remove('active');
    finalPromptAreaDiv.classList.remove('active');
    savedPromptsSection.style.display = 'none'; // Verberg ook opgeslagen prompts sectie

    // Toon de gevraagde sectie
    const elementToShow = document.getElementById(stepId);
    if (elementToShow) {
        if (stepId === 'saved-prompts-section') {
             elementToShow.style.display = 'block'; // Opgeslagen prompts gebruikt display block/none
        } else {
            elementToShow.classList.add('active'); // Andere stappen gebruiken de .active class
        }
    }
     window.scrollTo(0, 0); // Scroll naar boven bij elke stap wissel
}

// --- Kernlogica Functies ---

function handleTemplateSelection(event) {
    if (event.target.classList.contains('template-button') && event.target.dataset.template) {
        currentState.selectedTemplate = event.target.dataset.template;
        currentState.currentStepIndex = 0;
        currentState.answers = {}; // Reset antwoorden voor nieuw template
        showStep('question-area');
        renderStep();
    }
}

function renderStep() {
    const template = templates[currentState.selectedTemplate];
    if (!template) return; // Geen template geselecteerd

    if (currentState.currentStepIndex >= template.length) {
        renderFinalScreen(); // Alle vragen beantwoord
        return;
    }
     if (currentState.currentStepIndex < 0) {
        // Terug op stap 0, toon template selectie weer
         showStep('template-selection');
        return;
    }


    const stepData = template[currentState.currentStepIndex];

    questionTitleEl.textContent = stepData.question;
    questionTipEl.innerHTML = `<i>${stepData.tip}</i>`; // Gebruik innerHTML voor italics
    answerInputEl.value = currentState.answers[stepData.id] || '';
    answerInputEl.placeholder = `Jouw antwoord op: ${stepData.question}`;
    // Note: We houden de input als <textarea> voor eenvoud, type 'text'/'number' wordt niet dynamisch veranderd.

    // Update voortgang
    progressIndicatorEl.textContent = `Vraag ${currentState.currentStepIndex + 1} van ${template.length}`;

    // Zichtbaarheid Vorige knop
    backButton.style.display = currentState.currentStepIndex > 0 ? 'inline-block' : 'none';
}

function saveCurrentAnswer() {
    const template = templates[currentState.selectedTemplate];
     // Alleen opslaan als we binnen de grenzen van de vragenlijst zijn
    if (!template || currentState.currentStepIndex < 0 || currentState.currentStepIndex >= template.length) return;

    const stepData = template[currentState.currentStepIndex];
    currentState.answers[stepData.id] = answerInputEl.value.trim();
}

function handleNext() {
    saveCurrentAnswer(); // Sla antwoord op huidige stap op
    const template = templates[currentState.selectedTemplate];
    if (template && currentState.currentStepIndex < template.length) {
         currentState.currentStepIndex++;
    }
    renderStep(); // Toont volgende stap of finale scherm
}

function handleBack() {
    // Niet opslaan bij teruggaan, gebruiker moet expliciet 'Volgende' klikken
    if (currentState.currentStepIndex >= 0) { // Kan teruggaan van stap 0 naar template selectie
        currentState.currentStepIndex--;
        renderStep();
    }
}

function handleRestart() {
    if (confirm('Weet je zeker dat je opnieuw wilt beginnen? Alle huidige antwoorden gaan verloren.')) {
        currentState = {
            selectedTemplate: null,
            currentStepIndex: -1,
            answers: {}
        };
        showStep('template-selection');
        // Wis eventuele restanten
        answerInputEl.value = '';
        generatedPromptEl.textContent = '';
    }
}

function handleEditAnswers() {
    // Ga terug naar de eerste vraag van het huidige template
    if(currentState.selectedTemplate) {
         currentState.currentStepIndex = 0;
         showStep('question-area');
         renderStep();
    } else {
        // Geen template geselecteerd (zou niet mogen gebeuren vanaf finale scherm)
        handleRestart();
    }
}

function generatePrompt() {
    const answers = currentState.answers;
    const templateType = currentState.selectedTemplate ? templates[currentState.selectedTemplate][0].type || currentState.selectedTemplate : 'tekst'; // Gebruik een generieke term of de naam
    let prompt = `Genereer een ${templateType} gebaseerd op de volgende specificaties:\n\n`;

    const templateQuestions = templates[currentState.selectedTemplate];
    if (templateQuestions) {
        templateQuestions.forEach(step => {
            if (answers[step.id] && answers[step.id].trim() !== '') { // Voeg alleen toe als er een antwoord is
                // Maak de vraag (label) vet en duidelijk
                let label = step.question.replace('?', ''); // Verwijder vraagteken voor netheid
                prompt += `**${label}:**\n${answers[step.id]}\n\n`; // Antwoord op nieuwe regel voor leesbaarheid
            }
        });
    } else {
        // Fallback als template onbekend is
        prompt += "Kon geen specifieke template vinden. Gebruik de volgende antwoorden:\n";
         for (const key in answers) {
             if (answers[key] && answers[key].trim() !== '') {
                 prompt += `**${key}:**\n${answers[key]}\n\n`;
             }
         }
    }

    prompt += "---\nGebruik bovenstaande details om een coherente en complete tekst te schrijven die voldoet aan alle specificaties.";
    return prompt;
}

function renderFinalScreen() {
    showStep('final-prompt-area');
    generatedPromptEl.textContent = generatePrompt();
}

function copyToClipboard() {
    const promptText = generatedPromptEl.textContent;
    if (!promptText) return;

    navigator.clipboard.writeText(promptText)
        .then(() => {
            alert('✅ Prompt succesvol gekopieerd naar klembord!');
        })
        .catch(err => {
            console.error('Fout bij kopiëren naar klembord: ', err);
            alert('❌ Kopiëren mislukt. Probeer het handmatig.');
            // Fallback voor oudere browsers (zeldzaam nodig nu)
            // const textArea = document.createElement("textarea");
            // textArea.value = promptText;
            // document.body.appendChild(textArea);
            // textArea.select();
            // try {
            //     document.execCommand('copy');
            //     alert('✅ Prompt gekopieerd! (Fallback)');
            // } catch (err) {
            //     alert('❌ Kopiëren mislukt, ook met fallback.');
            // }
            // document.body.removeChild(textArea);
        });
}

// --- Local Storage Functies ---
const STORAGE_PREFIX = 'promptAssist_';

function saveCurrentPrompt() {
    const promptText = generatedPromptEl.textContent;
    if (!promptText || !currentState.selectedTemplate) {
        alert('Kan prompt niet opslaan. Genereer eerst een prompt.');
        return;
    }

    const key = `${STORAGE_PREFIX}${Date.now()}`;
    const dataToSave = {
        prompt: promptText,
        answers: currentState.answers,
        template: currentState.selectedTemplate,
        timestamp: new Date().toISOString() // Gebruik ISO voor makkelijk sorteren later
    };

    try {
        localStorage.setItem(key, JSON.stringify(dataToSave));
        alert('💾 Prompt opgeslagen!');
        loadSavedPrompts(); // Update de lijst direct (als die zichtbaar is)
    } catch (e) {
        console.error("Opslaan naar localStorage mislukt:", e);
        alert("❌ Opslaan mislukt. Mogelijk is de opslagruimte vol.");
    }
}

function loadSavedPrompts() {
    savedPromptsListEl.innerHTML = ''; // Leeg de lijst voor herpopulatie
    let hasSavedPrompts = false;

    const keys = Object.keys(localStorage)
                       .filter(key => key.startsWith(STORAGE_PREFIX))
                       .sort((a, b) => b.localeCompare(a)); // Sorteer op key (nieuwste eerst)

    keys.forEach(key => {
        try {
            const savedData = JSON.parse(localStorage.getItem(key));
            if (!savedData || !savedData.prompt) { // Basis check
                 console.warn(`Ongeldige data gevonden voor key ${key}, wordt overgeslagen.`);
                 return; // Sla deze ongeldige entry over
            }
            hasSavedPrompts = true;

            const listItem = document.createElement('li');
            listItem.dataset.key = key; // Sla key op voor makkelijke toegang

            const infoDiv = document.createElement('div');
            infoDiv.classList.add('prompt-info');
            infoDiv.title = 'Klik om deze prompt te laden en te bekijken';
            infoDiv.onclick = () => handleLoadSavedPrompt(key);

            const titleSpan = document.createElement('span');
            titleSpan.classList.add('prompt-title');
            // Maak een titel, bv. van het onderwerp of eerste paar woorden
            let displayTitle = `Prompt (${savedData.template || 'Onbekend'})`;
            if(savedData.answers && savedData.answers.topic) {
                displayTitle = `${savedData.answers.topic.substring(0, 40)}... (${savedData.template})`;
            } else if (savedData.answers && savedData.answers.standpoint) {
                 displayTitle = `${savedData.answers.standpoint.substring(0, 40)}... (${savedData.template})`;
            }
             titleSpan.textContent = displayTitle;


            const dateSpan = document.createElement('span');
            dateSpan.classList.add('prompt-date');
            dateSpan.textContent = `Opgeslagen op: ${new Date(savedData.timestamp).toLocaleString('nl-NL')}`;

            infoDiv.appendChild(titleSpan);
            infoDiv.appendChild(dateSpan);

            const actionsDiv = document.createElement('div');
            actionsDiv.classList.add('actions');

            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Verwijder';
            deleteButton.classList.add('danger', 'small'); // Kleinere knop
            deleteButton.onclick = (e) => {
                 e.stopPropagation(); // Voorkom laden bij klikken op delete
                 handleDeletePrompt(key);
            };

            actionsDiv.appendChild(deleteButton);

            listItem.appendChild(infoDiv);
            listItem.appendChild(actionsDiv);
            savedPromptsListEl.appendChild(listItem);

       } catch(e) {
           console.error(`Kon opgeslagen prompt niet laden (key: ${key}):`, e);
           // Optioneel: verwijder ongeldige entry?
           // localStorage.removeItem(key);
       }
    });

    // Toon bericht als er geen prompts zijn
    if (!hasSavedPrompts) {
        const noPromptsLi = document.createElement('li');
        noPromptsLi.classList.add('no-saved-prompts');
        noPromptsLi.textContent = 'Je hebt nog geen prompts opgeslagen.';
        savedPromptsListEl.appendChild(noPromptsLi);
         viewSavedButton.style.display = 'none'; // Verberg 'bekijk' knop als er niets is
    } else {
         viewSavedButton.style.display = 'inline-block'; // Toon 'bekijk' knop
    }
}


function handleLoadSavedPrompt(key) {
    try {
        const savedData = JSON.parse(localStorage.getItem(key));
        if (savedData && savedData.answers && savedData.template) {
            currentState.answers = savedData.answers;
            currentState.selectedTemplate = savedData.template;
            currentState.currentStepIndex = templates[savedData.template]?.length || 0; // Ga naar einde om prompt te tonen
            renderFinalScreen(); // Toon direct de finale prompt
        } else {
             alert('❌ Kon de prompt data niet correct laden.');
        }
    } catch (e) {
        console.error(`Fout bij laden van prompt ${key}:`, e);
        alert('❌ Er is een fout opgetreden bij het laden van deze prompt.');
    }
}

function handleDeletePrompt(key) {
    const listItem = savedPromptsListEl.querySelector(`li[data-key="${key}"]`);
    let promptTitle = listItem ? listItem.querySelector('.prompt-title').textContent : 'deze prompt';

    if (confirm(`Weet je zeker dat je "${promptTitle}" definitief wilt verwijderen?`)) {
        try {
            localStorage.removeItem(key);
            loadSavedPrompts(); // Herlaad de lijst om verwijdering te tonen
        } catch (e) {
            console.error(`Fout bij verwijderen van prompt ${key}:`, e);
            alert('❌ Verwijderen mislukt.');
        }
    }
}

function handleViewSaved() {
    loadSavedPrompts(); // Zorg dat lijst up-to-date is
    showStep('saved-prompts-section');
}

function handleBackToStart() {
     showStep('template-selection');
}


// --- Initialisatie & Event Listeners ---
function initializeApp() {
    // Koppel event listeners aan de juiste elementen
    templateSelectionDiv.addEventListener('click', handleTemplateSelection);
    nextButton.addEventListener('click', handleNext);
    backButton.addEventListener('click', handleBack);
    restartButton.addEventListener('click', handleRestart);
    restartButtonFinal.addEventListener('click', handleRestart);
    copyButton.addEventListener('click', copyToClipboard);
    saveButton.addEventListener('click', saveCurrentPrompt);
    editAnswersButton.addEventListener('click', handleEditAnswers);

    viewSavedButton.addEventListener('click', handleViewSaved);
    backToStartButton.addEventListener('click', handleBackToStart);


    // Start de app door de template selectie te tonen en opgeslagen prompts te laden
    showStep('template-selection');
    loadSavedPrompts(); // Laadt opgeslagen prompts bij start, maar sectie blijft verborgen
}

// Wacht tot de DOM volledig geladen is voordat we de app initialiseren
document.addEventListener('DOMContentLoaded', initializeApp);